function nirav(msg){
    if(confirm("are you shre to start"))
    {
        alert(msg);
    }
    else(
        alert("use canseld")
    )
}